#include <stdlib.h>
#include "dynamicArray.h"

void isEmpty(dynamicArray* self, void*data){
    if (self->data==NULL)
    {
        return 0;
    }

}

void pushBack(dynamicArray* self, void* data)
{
    if (self->count == self->cap)
    {
        self->cap = self->cap * 2;
        self->data = realloc(self->data, sizeof(void*) * self->cap);
    }
    self->data[self->count] = data;
    self->count ++;
}

void removeAt(dynamicArray* self, int index)
{
    if (index > -1 && index < self->count)
    {
        self->data[index] = self->data[self->count - 1];
        self->data[self->count - 1] = NULL;
        self->count --;
    }
}

void clear(dynamicArray* self)
{
    if (self->data)
    {
        free(self->data);
        self->data = NULL;
    }
}

void vecInit(dynamicArray* vector)
{
    vector->cap = INITIAL_CAP;
    vector->count = 0;
    vector->is_empty = isEmpty;
    vector->push_back = pushBack;
    vector->remove_at = removeAt;
    vector->clear_arr = clear;
    vector->data = malloc(sizeof(void*) * vector->cap);
}