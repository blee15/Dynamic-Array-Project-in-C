#include <stdio.h>
#include "dynamicArray.h"

int main (int argc, char** args)
{
    dynamicArray vector;
    vecInit(&vector);

    printf("Initialization - count: %d, capacity: %d\n", vector.count, vector.cap);

    
    vector.push_back(&vector, "Bethany");
    vector.push_back(&vector, "Lee");
    vector.push_back(&vector, "NYU");
    vector.push_back(&vector, "CSO201");
    vector.push_back(&vector, "Fall");
    vector.push_back(&vector, "2022");
    vector.push_back(&vector, "Project2");

    printf("Push Back - count: %d, limit: %d\n", vector.count, vector.cap);

    vector.remove_at(&vector, 2);

    printf("Remove At - count: %d, limit: %d\n", vector.count, vector.cap);

    printf("\nData:\n\n");

    for (int i = 0; i < vector.count; i ++)
    {
        printf("%s\n", (char*)vector.data[i]);
    }

    vector.clear_arr(&vector);

    vector.is_empty(&vector);

    printf("Is Empty - This array is empty.");

    return 0;
}