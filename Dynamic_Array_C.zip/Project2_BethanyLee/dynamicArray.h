#include <stdio.h>
#ifndef DYNAMICARRAY_H
#define DYNAMICARRAY_H
#define INITIAL_CAP 5

typedef struct dynamicArray
{
    void** data;
    int cap;
    int count;
    void(*is_empty)(struct dynamicArray*);
    void (*push_back)(struct dynamicArray*, void*);
    void (*remove_at)(struct dynamicArray*, int);
    void (*clear_arr)(struct dynamicArray*);
} dynamicArray;

void vecInit(dynamicArray* vector);

#endif